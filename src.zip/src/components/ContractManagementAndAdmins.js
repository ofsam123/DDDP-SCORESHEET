import { Layout, Table, Typography, Row } from "antd";
import React, { useEffect, useState } from "react";
import { formatDataGeneral, getAttributeValue, getFirstFileLinkIfExist } from "../utils/utils";
import Comment from "../components/Comments";

const indicators = [
    {
        indicator: 'No. of Projects awarded on contract',
        id: 'qZSULWbMR2R',
        value: 0
    },
    {
        indicator: 'No. of Projects completed',
        id: 'Hf5p1kc2JeR',
        value: 0
    },
    {
        indicator: 'No. of Projects completed and in use',
        id: 'yQEv4PwpL3t',
        value: 0
    },
    {
        indicator: 'No. of completed projects with Completion Reports',
        id: 's6gfdfWo5Nq',
        value: 0
    }
];

const contingencyIndicators = [
    {
        indicator: 'No. of projects with contingency provision',
        id: 'emhjn8smNMD',
        value: 0
    },
    {
        indicator: 'No. of projects with contingency used',
        id: 'hsnSY36kN8H',
        value: 0
    },
    {
        indicator: 'No. of projects with contingency used with written justification',
        id: 'faTS25Cv9RI',
        value: 0
    },
    {
        indicator: 'No. of projects with contingency duly approved and used',
        id: 'E24X37zoXD8',
        value: 0
    }
];

function ContractManagementAndAdmins({ year, district, data }) {

    const { Header, Content } = Layout;
    const { Title, Text } = Typography;
    const [projectList, setProjectList] = useState([]);
    const [scoreI, setScoreI] = useState(0);


    useEffect(() => {
        getData(); 
    }, [year, district, data]);


    const projectColumns = [
        { title: "No", dataIndex: "no", key: "no" },
        { title: "Projects", dataIndex: "project", key: "project" },
        { title: "Status", dataIndex: "status", key: "status" },
        { title: "TOR", dataIndex: "tor", key: "tor" },
        { title: "Contingency", dataIndex: "contingency", key: "contingency" },
        { title: "Completion Report", dataIndex: "report", key: "report" }
    ];

    function getData() {

        const projects = formatDataGeneral(data?.data, "Project & Programme Type", "Project") || [];
        const reports = data?.reports;

        const temp = [];

        projects.forEach((item, index) => {

            const reportLink = getFirstFileLinkIfExist(reports, "i1171kI9OBD", item.trackedEntity, "TrdgYOz3XUL");
            const torLink = getFirstFileLinkIfExist(reports, "X3uzSfGg9Wo", item.trackedEntity, "TrdgYOz3XUL");
            const contingencyLink = getFirstFileLinkIfExist(reports, "Rb98cVPjatA", item.trackedEntity, "JqitfVltImd");
            const status = getFirstFileLinkIfExist(reports, "tE3QKB203nh", item.trackedEntity, "rRWa5ghYO35", "status");

            const tempDataSet = {
                no: index + 1,
                project: getAttributeValue("Name", item),
                status: status ? status : "Not Provided",
                tor: torLink ? (
                    <a
                        className="px-2 text-primary fw-bold text-decoration-underline"
                        href={`https://dddp.gov.gh/api/events/files?eventUid=${torLink}&dataElementUid=X3uzSfGg9Wo`} target="_blank"
                        rel="noopener noreferrer"
                        title="Click here to see the uploaded document"
                    >
                        View TOR
                    </a>
                ) : (
                    "Not Uploaded"
                ),
                report: reportLink ? (
                    <a
                        className="px-2 text-primary fw-bold text-decoration-underline"
                        href={`https://dddp.gov.gh/api/events/files?eventUid=${reportLink}&dataElementUid=i1171kI9OBD`} target="_blank"
                        rel="noopener noreferrer"
                        title="Click here to see the uploaded document"
                    >
                        View Completion Report
                    </a>
                ) : (
                    "Not Uploaded"
                ),
                contingency: contingencyLink ? (
                    <a
                        className="px-2 text-primary fw-bold text-decoration-underline"
                        href={`https://dddp.gov.gh/api/events/files?eventUid=${contingencyLink}&dataElementUid=Rb98cVPjatA`} target="_blank"
                        rel="noopener noreferrer"
                        title="Click here to see the uploaded document"
                    >
                        View Contingency
                    </a>
                ) : (
                    "Not Uploaded"
                )
            };

            temp.push(tempDataSet);

            
        });

        let score = 3;

        for(let project of temp){
            if(project.report === "Not Uplaoded" || project.status !== "Completed and in-use"){
                score = 0;
            }
        }

        if(temp.length === 0){
            score = 0;
        }

        setProjectList(temp)
        setScoreI(score);

    }


    return (
        <Comment
            data={projectList}
            year={year}
            districtId={district}
            tableCommentedId={`pi1.0-1.3-${year}`}
        >
            {({ renderCommentInput, renderCommentList }) => (
                <>
                    <Title level={3} style={{ marginTop: "20px" }}>PI 1.0 - 1.3 Records on Contract Management and Administration</Title>
                    <Title level={4} style={{ marginTop: "20px" }}>Assessment Guide/ Requirement</Title>
                    <Content>
                        From the DCD, obtain information on contract management and administration:<br /><br />
                        <ol>
                            <li type="i">
                                If final completion reports (signed off) on all completed projects are available
                                and all completed projects are in use, score 3, else score 0
                            </li>

                        </ol>
                    </Content>

                    <Title level={5} style={{ marginTop: "20px" }}>
                        Maximum Score <strong>3</strong>
                    </Title>


                    <Row align="middle">
                        <Title level={5} style={{ marginTop: "20px", marginRight: "20px", marginLeft: "10px" }}>
                            PI 1.0-1.3 Actual Score: <strong>{scoreI}</strong>
                        </Title>
                        {renderCommentInput()}
                    </Row>

                    <Title level={5} style={{ marginTop: "20px" }}>
                         Evidence of project completion and use
                    </Title>
                    <Table
                        columns={projectColumns}
                        dataSource={projectList}
                        pagination={false}
                        bordered
                    />

                    {renderCommentList()}
                </>
            )}
        </Comment>
    );
}

export default ContractManagementAndAdmins;