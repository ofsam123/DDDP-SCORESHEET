import { Layout, Table, Typography, Row, Space, Col,Text } from "antd";
import React, { forwardRef, useImperativeHandle, useState } from "react";
import Comment from "../components/Comments";

const MaintenanceInfrastructure = forwardRef(({
  year,
  buildingInspectorateData,
  districtId,
  hideComment
}, ref) => {
  const { Header, Content } = Layout;
  const { Title, Text } = Typography;
  const [maxScore, setMaxScore] = useState(5);

  useImperativeHandle(ref, () => ({
    getData: () => ({
      indicator: "SDI2",
      area: "Basic/ Social Services",
      maxScore,
      buildingInspectorateData
    }),
  }));

  const buildingInspectorateColumn = [
    { title: "Date Established", dataIndex: "date", key: "date" },
    { title: "Supervisor", dataIndex: "supervisor", key: "supervisor" },
    { title: "address", dataIndex: "address", key: "address" },
    { title: "Category of staff", dataIndex: "category", key: "category" },
    { title: "Function performed by Works Department", dataIndex: "department", key: "department" }
  ];

  return (
    <Comment
      data={buildingInspectorateData}
      year={year}
      districtId={districtId}
      tableCommentedId={`sdi2.0-2.4-${year}`}
      hideComment={hideComment}
    >
      {({ renderCommentInput, renderCommentList }) => (
        <>
          <Title level={3} style={{ marginTop: "30px" }}>SDI 2.0 - 2.4 Maintenance of Infrastructure of Public Interest</Title>
          <Title level={4} style={{ marginTop: "30px" }}>Assessment Guide/ Requirement</Title>
          <Content>
            From the DCD receive information on the Operations & Maintenance Plan and its implementation:<br /><br />
            <ol>
              <li type="i">If the plan includes public places of interest such as Markets, Community Centres, Lorry Parks, U-Drains, Schools, Hospitals or Clinics, CHPS Compounds, etc, score 1;</li>
              <li type="i" className="py-1">If the budget allocation for O&M is at least 10% of Capital expenditure budget, score 1; and</li>
              <li type="i">If there is evidence of expenditure for O&M Budget proportional to 10% of the Capital Expenditure and there is evidence of implementation of the O&M Plan, score 3</li>
            </ol>

            <br />
          </Content>

          <Col align="start">

            <Title level={5} style={{ marginTop: "30px", marginRight: "10px" }}>Maximum Score <strong>{maxScore}</strong></Title>

            {!hideComment && renderCommentInput()}
          </Col>
          <Title level={5} style={{ marginTop: "30px" }}>I. Evidence of O&M Plan in existence</Title>
          <Space><Text strong>Actual Score: </Text> <Text>{!true ? '1' : '0'}</Text></Space>
          {buildingInspectorateData && <Table
            columns={buildingInspectorateColumn}
            dataSource={buildingInspectorateData}
            pagination={false} bordered />}



          <Title level={5} style={{ marginTop: "30px" }}>II. O&M Budget to Capital Budget</Title>
          <Space><Text strong>Actual Score: </Text> <Text>{!true ? '1' : '0'}</Text></Space>
          {buildingInspectorateData && <Table
            columns={buildingInspectorateColumn}
            dataSource={buildingInspectorateData}
            pagination={false} bordered />}

          <Title level={5} style={{ marginTop: "30px" }}>III. Evidence of implementation of O&M Plan</Title>
          <Row align="middle">
            <Space style={{ marginRight: "20px", marginLeft: "10px" }}>
              <Text strong>Actual Score: </Text>
              <Text>{!true ? '1' : '0'}</Text>
            </Space>

          </Row>
          {buildingInspectorateData && <Table
            columns={buildingInspectorateColumn}
            dataSource={buildingInspectorateData}
            pagination={false} bordered />}

          <Content>
            Calculated as: % of IGF i=on Sanitation = (B/A) x 100
          </Content>

          {renderCommentList()}
        </>
      )}
    </Comment>
  );
})

export default MaintenanceInfrastructure;